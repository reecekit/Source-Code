﻿using System;
using System.Net.NetworkInformation;

namespace Network
{
    class Pinger
    {
        private bool firstPing = true;
        string response = "";
        private int packetsSent = 0;
        private int packetsReceived = 0;
        private int packetsLost = 0;
        private int roundTripMin = 0;
        private int roundTripMax = 0;
        private int roundTripAvg = 0;
        PingReply reply = null;

        public string SendPing(string ipAddress)
        {
            response = "";
            Ping pingSender = new Ping();

            try
            {
                reply = pingSender.Send(ipAddress);
             
                if(firstPing)
                {
                    firstPing = false;
                    response += "Pinging " + reply.Address.ToString() + " with " + reply.Buffer.Length + " bytes of data:\r\n";
                }

                if (reply.Status == IPStatus.Success)
                {
                    packetsReceived++;
                    response += "Reply from " + reply.Address.ToString() + ":  "
                    + "Bytes=" + reply.Buffer.Length + "  "
                    + "Time=" + reply.RoundtripTime.ToString() + "ms  ";

                    // This will throw an exception when pinging an address using a name like www.yahoo.com
                    // instead of an IP address.
                    response += "TTL=" + reply.Options.Ttl + "\r\n";
                }
            }
            catch (PingException)
            // If there is no response from a ping then a PingException will be thrown.
            {
                packetsLost++;
                response += "Request timed out.\r\n";
            }
            // If pinging an address using a name like www.yahoo.com instead of an IP address
            // reply.Options.Ttl will return null.
            catch (NullReferenceException)
            {
                response += "\r\n";
            }

            packetsSent++;
            return response;
        }

        public string packetStatistics()
        {
            response = "Ping statistics for " + reply.Address.ToString() + ":"
                + "\r\nPackets: Sent " + packetsSent + ", Received " + packetsReceived
                + ", Lost " + packetsLost + " (" + ((packetsReceived / packetsSent) / 100) + "% Loss)";
            return response;
        }
    }
}
