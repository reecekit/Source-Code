﻿using System;
using System.Windows.Forms;
using Network;

namespace PingIT
{
    public partial class PingIT : Form
    {
        Pinger Ping = new Pinger();

        public PingIT()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Response.AppendText(Ping.SendPing(IPAddress.Text));
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("PingIT V1.0\r\nCopyright (C) 2016 by Reece Kitchens", "About");
        }
    }
}
