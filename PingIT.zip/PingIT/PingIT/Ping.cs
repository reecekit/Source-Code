﻿using System;
using System.Net.NetworkInformation;

namespace Network
{
    class Pinger
    {
        public string SendPing(string ipAddress)
        {
            string response = "";
            Ping pingSender = new Ping();

            try
            {
                PingReply reply = pingSender.Send(ipAddress);
                response += "Pinging " + reply.Address.ToString() + " with " + reply.Buffer.Length + " bytes of data:\r\n";

                if (reply.Status == IPStatus.Success)
                {
                    response += "Reply from " + reply.Address.ToString() + ":  "
                    + "Bytes=" + reply.Buffer.Length + "  "
                    + "Time=" + reply.RoundtripTime.ToString() + "ms  ";

                    // This will throw an exception when pinging an address using a name like www.yahoo.com
                    // instead of an IP address.
                    response += "TTL=" + reply.Options.Ttl + "\r\n";
                }
            }
            catch (PingException)
            // If there is no response from a ping then a PingException will be thrown.
            {
                response += "Request timed out.\r\n";
            }
            // If pinging an address using a name like www.yahoo.com instead of an IP address
            // reply.Options.Ttl will return null.
            catch (NullReferenceException)
            {
                response += "\r\n";
            }
            return response;
        }
    }
}
