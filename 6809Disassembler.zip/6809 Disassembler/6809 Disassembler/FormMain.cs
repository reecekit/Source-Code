﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Colossus
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private byte[] fileData;    // Holds all the bytes to be disassembled.

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog Ofd = new OpenFileDialog();
            Ofd.ShowDialog();
            
            fileData = File.ReadAllBytes(Ofd.FileName);
            
            Disassembler_6809 Disassembler = new Disassembler_6809(fileData);

            string disassembly = Disassembler.Disassemble();
            while (disassembly != "1200")
            {
                richCodeWindow.Text += disassembly + "\n";
                disassembly = Disassembler.Disassemble();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox Box = new AboutBox();
            Box.ShowDialog();
        }
    }
}
