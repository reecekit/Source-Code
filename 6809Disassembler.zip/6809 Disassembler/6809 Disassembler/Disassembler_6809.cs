using System;
using System.Collections.Generic;
using System.Text;

namespace Colossus
{
    class Disassembler_6809
    {
        private int index = 0;
        private string DisassembledCode = null;
        private enum AddressMode { Direct, Inherent, Relative, Indexed, Immediate, Extended };
        private byte[] codeToDisassemble;

        private object[,] instructionTable = { {0x00, "NEG", AddressMode.Direct},
                                               {0x03, "COM", AddressMode.Direct},
                                               {0x04, "LSR", AddressMode.Direct},
                                               {0x06, "ASL", AddressMode.Direct},
                                               {0x06, "ROR", AddressMode.Direct},
                                               {0x07, "ASR", AddressMode.Direct},
                                               {0x08, "LSL", AddressMode.Direct},
                                               {0x09, "ROL", AddressMode.Direct},
                                               {0x0A, "DEC", AddressMode.Direct},
                                               {0x0C, "INC", AddressMode.Direct},
                                               {0x0D, "TST", AddressMode.Direct},
                                               {0x0E, "JMP", AddressMode.Direct},
                                               {0x0F, "CLR", AddressMode.Direct},
                                               {0x12, "NOP", AddressMode.Inherent},
                                               {0x13, "SYNC", AddressMode.Inherent},
                                               {0x16, "LBRA", AddressMode.Relative},
                                               {0x17, "LBSR", AddressMode.Relative},
                                               {0x19, "DAA", AddressMode.Inherent},
                                               {0x1A, "ORCC", AddressMode.Immediate},
                                               {0x1C, "ANDCC", AddressMode.Immediate},
                                               {0x1D, "SEX", AddressMode.Inherent},
                                               {0x1E, "EXG", AddressMode.Inherent},
                                               {0x1F, "TFR", AddressMode.Inherent},
                                               {0x20, "BRA", AddressMode.Relative},
                                               {0x21, "BRN", AddressMode.Relative},
                                               {0x22, "BHI", AddressMode.Relative},
                                               {0x23, "BLS", AddressMode.Relative},
                                               {0x24, "BCC", AddressMode.Relative},
                                               {0x24, "BHS", AddressMode.Relative},
                                               {0x25, "BCS", AddressMode.Relative},
                                               {0x25, "BLO", AddressMode.Relative},
                                               {0x26, "BNE", AddressMode.Relative},
                                               {0x27, "BEQ", AddressMode.Relative},
                                               {0x28, "BVC", AddressMode.Relative},
                                               {0x29, "BVS", AddressMode.Relative},
                                               {0x2A, "BPL", AddressMode.Relative},
                                               {0x2B, "BMI", AddressMode.Relative},
                                               {0x2C, "BGE", AddressMode.Relative},
                                               {0x2D, "BLT", AddressMode.Relative},
                                               {0x2E, "BGT", AddressMode.Relative},
                                               {0x2F, "BLE", AddressMode.Relative},
                                               {0x30, "LEAX", AddressMode.Indexed},
                                               {0x31, "LEAY", AddressMode.Indexed},
                                               {0x32, "LEAS", AddressMode.Indexed},
                                               {0x33, "LEAU", AddressMode.Indexed},
                                               {0x34, "PSHS", AddressMode.Inherent},
                                               {0x35, "PULS", AddressMode.Inherent},
                                               {0x36, "PSHU", AddressMode.Inherent},
                                               {0x37, "PULU", AddressMode.Inherent},
                                               {0x39, "RTS", AddressMode.Inherent},
                                               {0x3A, "ABX", AddressMode.Inherent},
                                               {0x3B, "RTI", AddressMode.Inherent},
                                               {0x3C, "CWAI", AddressMode.Inherent},
                                               {0x3D, "MUL", AddressMode.Inherent},
                                               {0x3F, "SWI", AddressMode.Inherent},
                                               {0x40, "NEGA", AddressMode.Inherent},
                                               {0x43, "COMA", AddressMode.Inherent},
                                               {0x44, "LSRA", AddressMode.Inherent},
                                               {0x46, "RORA", AddressMode.Inherent},
                                               {0x47, "ASRA", AddressMode.Inherent},
                                               {0x48, "ASLA", AddressMode.Inherent},
                                               {0x48, "LSLA", AddressMode.Inherent},
                                               {0x49, "ROLA", AddressMode.Inherent},
                                               {0x4A, "DECA", AddressMode.Inherent},
                                               {0x4C, "INCA", AddressMode.Inherent},
                                               {0x4D, "TSTA", AddressMode.Inherent},
                                               {0x4F, "CLRA", AddressMode.Inherent},
                                               {0x50, "NEGB", AddressMode.Inherent},
                                               {0x53, "COMB", AddressMode.Inherent},
                                               {0x54, "LSRB", AddressMode.Inherent},
                                               {0x56, "RORB", AddressMode.Inherent},
                                               {0x57, "ASRB", AddressMode.Inherent},
                                               {0x58, "ALSB", AddressMode.Inherent},
                                               {0x58, "LSLB", AddressMode.Inherent},
                                               {0x59, "ROLB", AddressMode.Inherent},
                                               {0x5A, "DECB", AddressMode.Inherent},
                                               {0x5C, "INCB", AddressMode.Inherent},
                                               {0x5D, "TSTB", AddressMode.Inherent},
                                               {0x5F, "CLRB", AddressMode.Inherent},
                                               {0x60, "NEG", AddressMode.Indexed},
                                               {0x63, "COM", AddressMode.Indexed},
                                               {0x64, "LSR", AddressMode.Indexed},
                                               {0x66, "ROR", AddressMode.Indexed},
                                               {0x67, "ASR", AddressMode.Indexed},
                                               {0x68, "ASL", AddressMode.Indexed},
                                               {0x68, "LSL", AddressMode.Indexed},
                                               {0x69, "ROL", AddressMode.Indexed},
                                               {0x6A, "DEC", AddressMode.Indexed},
                                               {0x6C, "INC", AddressMode.Indexed},
                                               {0x6D, "TST", AddressMode.Indexed},
                                               {0x6E, "JMP", AddressMode.Indexed},
                                               {0x6F, "CLR", AddressMode.Indexed},
                                               {0x70, "NEG", AddressMode.Extended},
                                               {0x73, "COM", AddressMode.Extended},
                                               {0x74, "LSR", AddressMode.Extended},
                                               {0x76, "ROR", AddressMode.Extended},
                                               {0x77, "ASR", AddressMode.Extended},
                                               {0x78, "ASL", AddressMode.Extended},
                                               {0x78, "LSL", AddressMode.Extended},
                                               {0x79, "ROL", AddressMode.Extended},
                                               {0x7A, "DEC", AddressMode.Extended},
                                               {0x7C, "INC", AddressMode.Extended},
                                               {0x7D, "TST", AddressMode.Extended},
                                               {0x7E, "JMP", AddressMode.Extended},
                                               {0x7F, "CLR", AddressMode.Extended},
                                               {0x80, "SUBA", AddressMode.Immediate},
                                               {0x81, "CMPA", AddressMode.Immediate},
                                               {0x82, "SBCA", AddressMode.Immediate},
                                               {0x83, "SUBD", AddressMode.Immediate},
                                               {0x84, "ANDA", AddressMode.Immediate},
                                               {0x85, "BITA", AddressMode.Immediate},
                                               {0x86, "LDA", AddressMode.Immediate},
                                               {0x88, "EORA", AddressMode.Immediate},
                                               {0x89, "ADCA", AddressMode.Immediate},
                                               {0x8A, "ORA", AddressMode.Immediate},
                                               {0x8B, "ADDA", AddressMode.Immediate},
                                               {0x8C, "CMPX", AddressMode.Immediate},
                                               {0x8D, "BSR", AddressMode.Relative},
                                               {0x8E, "LDX", AddressMode.Immediate},
                                               {0x90, "SUBA", AddressMode.Direct},
                                               {0x91, "CMPA", AddressMode.Direct},
                                               {0x92, "SBCA", AddressMode.Direct},
                                               {0x93, "SUBD", AddressMode.Direct},
                                               {0x94, "ANDA", AddressMode.Direct},
                                               {0x95, "BITA", AddressMode.Direct},
                                               {0x96, "LDA", AddressMode.Direct},
                                               {0x97, "STA", AddressMode.Direct},
                                               {0x98, "EORA", AddressMode.Direct},
                                               {0x99, "ADCA", AddressMode.Direct},
                                               {0x9A, "ORA", AddressMode.Direct},
                                               {0x9B, "ADDA", AddressMode.Direct},
                                               {0x9C, "CMPX", AddressMode.Direct},
                                               {0x9D, "JSR", AddressMode.Direct},
                                               {0x9E, "LDX", AddressMode.Direct},
                                               {0x9F, "STX", AddressMode.Direct},
                                               {0xA0, "SUBA", AddressMode.Indexed},
                                               {0xA1, "CMPA", AddressMode.Indexed},
                                               {0xA2, "SBCA", AddressMode.Indexed},
                                               {0xA3, "SUBD", AddressMode.Indexed},
                                               {0xA4, "ANDA", AddressMode.Indexed},
                                               {0xA5, "BITA", AddressMode.Indexed},
                                               {0xA6, "LDA", AddressMode.Indexed},
                                               {0xA7, "STA", AddressMode.Indexed},
                                               {0xA8, "EORA", AddressMode.Indexed},
                                               {0xA9, "ADCA", AddressMode.Indexed},
                                               {0xAA, "ORA", AddressMode.Indexed},
                                               {0xAB, "ADDA", AddressMode.Indexed},
                                               {0xAC, "CMPX", AddressMode.Indexed},
                                               {0xAD, "JSR", AddressMode.Indexed},
                                               {0xAE, "LDX", AddressMode.Indexed},
                                               {0xAF, "STX", AddressMode.Indexed},
                                               {0xB0, "SUBA", AddressMode.Extended},
                                               {0xB1, "CMPA", AddressMode.Extended},
                                               {0xB2, "SBCA", AddressMode.Extended},
                                               {0xB3, "SUBD", AddressMode.Extended},
                                               {0xB4, "ANDA", AddressMode.Extended},
                                               {0xB5, "BITA", AddressMode.Extended},
                                               {0xB6, "LDA", AddressMode.Extended},
                                               {0xB7, "STA", AddressMode.Extended},
                                               {0xB8, "EORA", AddressMode.Extended},
                                               {0xB9, "ADCA", AddressMode.Extended},
                                               {0xBA, "ORA", AddressMode.Extended},
                                               {0xBB, "ADDA", AddressMode.Extended},
                                               {0xBC, "CMPX", AddressMode.Extended},
                                               {0xBD, "JSR", AddressMode.Extended},
                                               {0xBE, "LDX", AddressMode.Extended},
                                               {0xBF, "STX", AddressMode.Extended},
                                               {0xC0, "SUBB", AddressMode.Immediate},
                                               {0xC1, "CMPB", AddressMode.Immediate},
                                               {0xC2, "SBCB", AddressMode.Immediate},
                                               {0xC3, "ADDD", AddressMode.Immediate},
                                               {0xC4, "ANDB", AddressMode.Immediate},
                                               {0xC5, "BITB", AddressMode.Immediate},
                                               {0xC6, "LDB", AddressMode.Immediate},
                                               {0xC8, "EORB", AddressMode.Immediate},
                                               {0xC9, "ADCB", AddressMode.Immediate},
                                               {0xCA, "ORB", AddressMode.Immediate},
                                               {0xCB, "ADDB", AddressMode.Immediate},
                                               {0xCC, "LDD", AddressMode.Immediate},
                                               {0xCE, "LDU", AddressMode.Immediate},
                                               {0xD0, "SUBB", AddressMode.Direct},
                                               {0xD1, "CMPB", AddressMode.Direct},
                                               {0xD2, "SBCB", AddressMode.Direct},
                                               {0xD3, "ADDD", AddressMode.Direct},
                                               {0xD4, "ANDB", AddressMode.Direct},
                                               {0xD5, "BITB", AddressMode.Direct},
                                               {0xD6, "LDB", AddressMode.Direct},
                                               {0xD7, "STB", AddressMode.Direct},
                                               {0xD8, "EORB", AddressMode.Direct},
                                               {0xD9, "ADCB", AddressMode.Direct},
                                               {0xDA, "ORB", AddressMode.Direct},
                                               {0xDB, "ADDB", AddressMode.Direct},
                                               {0xDC, "LDD", AddressMode.Direct},
                                               {0xDD, "STD", AddressMode.Direct},
                                               {0xDE, "LDU", AddressMode.Direct},
                                               {0xDF, "STU", AddressMode.Direct},
                                               {0xE0, "SUBB", AddressMode.Indexed},
                                               {0xE1, "CMPB", AddressMode.Indexed},
                                               {0xE2, "SBCB", AddressMode.Indexed},
                                               {0xE3, "ADDD", AddressMode.Indexed},
                                               {0xE4, "ANDB", AddressMode.Indexed},
                                               {0xE5, "BITB", AddressMode.Indexed},
                                               {0xE6, "LDB", AddressMode.Indexed},
                                               {0xE7, "STB", AddressMode.Indexed},
                                               {0xE8, "EORB", AddressMode.Indexed},
                                               {0xE9, "ADCB", AddressMode.Indexed},
                                               {0xEA, "ORB", AddressMode.Indexed},
                                               {0xEB, "ADDB", AddressMode.Indexed},
                                               {0xEC, "LDD", AddressMode.Indexed},
                                               {0xED, "STD", AddressMode.Indexed},
                                               {0xEE, "LDU", AddressMode.Indexed},
                                               {0xEF, "STU", AddressMode.Indexed},
                                               {0xF0, "SUBB", AddressMode.Extended},
                                               {0xF1, "SUBB", AddressMode.Extended},
                                               {0xF2, "SBCB", AddressMode.Extended},
                                               {0xF3, "ADDD", AddressMode.Extended},
                                               {0xF4, "ANDB", AddressMode.Extended},
                                               {0xF5, "BITB", AddressMode.Extended},
                                               {0xF6, "LDB", AddressMode.Extended},
                                               {0xF7, "STB", AddressMode.Extended},
                                               {0xF8, "EORB", AddressMode.Extended},
                                               {0xF9, "ADCB", AddressMode.Extended},
                                               {0xFA, "ORB", AddressMode.Extended},
                                               {0xFB, "ADDB", AddressMode.Extended},
                                               {0xFC, "LDD", AddressMode.Extended},
                                               {0xFD, "STD", AddressMode.Extended},
                                               {0xFE, "LDU", AddressMode.Extended},
                                               {0xFF, "STU", AddressMode.Extended},
                                               {0x1021, "LBRN", AddressMode.Relative},
                                               {0x1022, "LBHI", AddressMode.Relative},
                                               {0x1023, "LBLS", AddressMode.Relative},
                                               {0x1024, "LBCC", AddressMode.Relative},
                                               {0x1024, "LBHS", AddressMode.Relative},
                                               {0x1025, "LBCS", AddressMode.Relative},
                                               {0x1025, "LBLO", AddressMode.Relative},
                                               {0x1026, "LBNE", AddressMode.Relative},
                                               {0x1027, "LBEQ", AddressMode.Relative},
                                               {0x1028, "LBVC", AddressMode.Relative},
                                               {0x1029, "LBVS", AddressMode.Relative},
                                               {0x102A, "LBPL", AddressMode.Relative},
                                               {0x102B, "LBMI", AddressMode.Relative},
                                               {0x102C, "LBGE", AddressMode.Relative},
                                               {0x102D, "LBLT", AddressMode.Relative},
                                               {0x102E, "LBGT", AddressMode.Relative},
                                               {0x102F, "LBLE", AddressMode.Relative},
                                               {0x103F, "SWI2", AddressMode.Inherent},
                                               {0x1083, "CMPD", AddressMode.Immediate},
                                               {0x108C, "CMPY", AddressMode.Immediate},
                                               {0x108E, "LDY", AddressMode.Immediate},
                                               {0x1093, "CMPD", AddressMode.Direct},
                                               {0x109C, "CMPY", AddressMode.Direct},
                                               {0x109E, "LDY", AddressMode.Direct},
                                               {0x109F, "STY", AddressMode.Direct},
                                               {0x10A3, "CMPD", AddressMode.Indexed},
                                               {0x10AC, "CMPY", AddressMode.Indexed},
                                               {0x10AE, "LDY", AddressMode.Indexed},
                                               {0x10AF, "STY", AddressMode.Indexed},
                                               {0x10B3, "CMPD", AddressMode.Extended},
                                               {0x10BC, "CMPY", AddressMode.Extended},
                                               {0x10BE, "LDY", AddressMode.Extended},
                                               {0x10BF, "STY", AddressMode.Extended},
                                               {0x10CE, "LDS", AddressMode.Immediate},
                                               {0x10DE, "LDS", AddressMode.Direct},
                                               {0x10DF, "STS", AddressMode.Direct},
                                               {0x10EE, "LDS", AddressMode.Indexed},
                                               {0x10EF, "STS", AddressMode.Indexed},
                                               {0x10FE, "LDS", AddressMode.Extended},
                                               {0x10FF, "STS", AddressMode.Extended},
                                               {0x113F, "SWI3", AddressMode.Inherent},
                                               {0x1183, "CMPU", AddressMode.Immediate},
                                               {0x118C, "CMPS", AddressMode.Immediate},
                                               {0x1193, "CMPU", AddressMode.Direct},
                                               {0x119C, "CMPS", AddressMode.Direct},
                                               {0x11A3, "CMPU", AddressMode.Indexed},
                                               {0x11AC, "CMPS", AddressMode.Indexed},
                                               {0x11B3, "CMPU", AddressMode.Extended},
                                               {0x11BC, "CMPS", AddressMode.Extended}
                                             };

        public Disassembler_6809(byte[] data)
        {
            codeToDisassemble = data;
        }

        // Retrieves the next instruction to be processed.
        private int GetNextInstruction()
        {
            int hexCode = 0;    // Hold for the 8 or 16 bit instruction.
            
            // Determine if instruction is 8 or 16 bits.
            if (index < codeToDisassemble.Length)
            {
                if ((codeToDisassemble[index] == 0x10) || (codeToDisassemble[index] == 0x11))
                {
                    hexCode = GetNextWord();
                }
                else
                {
                    hexCode = GetNextByte();
                }
            }
            
            return hexCode;
        }

        // Finds the location of the instructionCode in the instructionArray.
        private int GetIndexOfInstruction(int InstructionCode)
        {
            // Find index of Instruction
            int index = 0;
            while (InstructionCode != (int)instructionTable[index, 0])
            {
               index++;
            }

            return index;            
        }

        // Dissassembles the next instruction and returns a string representation.
        public string Disassemble()
        {
            DisassembledCode = null;
            int instruction = GetNextInstruction();
            int index = GetIndexOfInstruction(instruction);
            AddressMode mode = (AddressMode)instructionTable[index, 2];

            if(index > 18)
               DisassembledCode = "1200";
            else
            switch (mode)
            {             
                case AddressMode.Direct:
                    DisassembledCode = FormatDataDirect(index);
                    break;
                case AddressMode.Extended:
                    DisassembledCode = FormatDataExtended(index);
                    break;
                case AddressMode.Immediate:
                    DisassembledCode = FormatDataImmediate(index);
                    break;
                case AddressMode.Indexed:
                    DisassembledCode = FormatDataIndexed(index);
                    break;
                case AddressMode.Inherent:
                    DisassembledCode = FormatDataInherent(index);
                    break;
                case AddressMode.Relative:
                    DisassembledCode = FormatDataRelative(index);
                    break;
            }
            
            return DisassembledCode; 
        }

        // Formats the output string for instructions that use inherent addressing which assemble as a single or
        // double byte opcode.
        private string FormatDataInherent(int i)
        {
            // Format for output when opCode is 8 bits or less.
            if ((int)instructionTable[i,0] <= 0xFF)
                return String.Format("{0:X4}: {1:X2}         {2}", index, (int)instructionTable[i, 0], (string)instructionTable[i,1]);

            // Format for output when opCode is greater than 8 bits.
            if ((int)instructionTable[i, 0] > 0xFF)
                return String.Format("{0:X4}: {1:X4}       {2}", index, (int)instructionTable[i, 0], (string)instructionTable[i, 1]);

            return "ERROR: Format string not found";
        }

        // Formats the output string for instructions that use direct addressing.
        private string FormatDataDirect(int i)
        {
            short opRand = GetNextByte();

            // Format for output when opCode is less than 8 bits.
            if ((int)instructionTable[i, 0] <= 0xFF)
                return String.Format("{0:X4}: {1:X2}   {2:X2}    {3}\t ${4:X2},DP", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], opRand);

            // Format for output when opCode is greater than 8 bits.
            if ((int)instructionTable[i, 0] > 0xFF)
                return String.Format("{0:X4}: {1:X4} {2:X2}    {3}\t ${4:X2},DP", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], opRand);

            return "ERROR: Format string not found";
        }

        // Formats the output string for instructions that use extended addressing.
        private string FormatDataExtended(int i)
        {
            short opRand = GetNextWord();

            // Format for output when opCode is less than 8 bits.
            if ((int)instructionTable[i, 0] <= 0xFF)
                return String.Format("{0:X4}: {1:X2}   {2:X4}  {3}\t [${4:X4}]", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], opRand);

            // Format for output when opCode is greater than 8 bits.
            if ((int)instructionTable[i, 0] > 0xFF)
                return String.Format("{0:X4}: {1:X4} {2:X4}  {3}\t [${4:X4}]", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], opRand);

            return "ERROR: Format string not found";
        }

        // Formats the output string for instructions that use immediate addressing in which the data follows the
        // opcode.
        private string FormatDataImmediate(int i)
        {
            short opRand = 0;

            switch ((int)instructionTable[i, 0])    // Determine if instruction has 8 or 16 bit oprand.
            {
                case 0xC3:
                case 0x1083:
                case 0x118C:
                case 0x1183:
                case 0x8C:
                case 0x108C:
                case 0xCC:
                case 0x10CE:
                case 0xCE:
                case 0x8E:
                case 0x108E:
                case 0x83:
                    opRand = GetNextWord();    // 16 bit oprand.
                    break;
                default:
                    opRand = GetNextByte();    // 8 bit oprand.
                    break;
            }

            // Format for output when opCode and opRand are 8 bits or less.
            if (((int)instructionTable[i, 0] <= 0xFF) && (opRand <= 0xFF))
                return String.Format("{0:X4}: {1:X2}   {2:X2}    {3}\t #${4:X2}", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], opRand);

            // Format for output when opCode is greater than 8 bits and opRand is 8 bits or less.
            if (((int)instructionTable[i, 0] > 0xFF) && (opRand <= 0xFF))
                return String.Format("{0:X4}: {1:X4} {2:X2}    {3}\t #${4:X2}", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], opRand);

            // Format for output when opCode is less than 8 bits and opRand is greater then 8 bits.
            if (((int)instructionTable[i, 0] <= 0xFF) && (opRand > 0xFF))
                return String.Format("{0:X4}: {1:X2}   {2:X4}  {3}\t #${4:X4}", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], opRand);

            // Format for output when opCode and opRand are greater than 8 bits.
            if (((int)instructionTable[i, 0] > 0xFF) && (opRand > 0xFF))
                return String.Format("{0:X4}: {1:X4} {2:X4}  {3}\t #${4:X4}", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], opRand);

            return "ERROR: Format string not found";
        }
        
        // Formats the output string for instructions that use indexed addressing.
        private string FormatDataIndexed(int i)
        {
            string returnString = null;
            string reg = null;
            short offset = 0;
            short temp = 0;
            short opRand = GetNextByte();

            temp = opRand;
            byte register = (byte)(temp &= 0x60);  // 0RR00000 - Get register.
            switch (register)
            {
                case 0x00:
                    reg = "X";
                    break;
                case 0x20:
                    reg = "Y";
                    break;
                case 0x40:
                    reg = "U";
                    break;
                case 0x60:
                    reg = "S";
                    break;
            }
            
            temp = opRand;
            temp &= 0x9F;      // 1XX11111 - Remove bits 6 and 7. 
            switch (temp)
            { 
                case 0x84:      // ,R - 1RR00100, No offset, Non indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t ," + reg, index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x94:      // ,R - 1RR10100, No offset, Indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t [," + reg + "]", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x88:      // n,R - 1RR01000, 8 Bit offset, Non indirect addressing.
                    offset = GetByteOffset(GetNextByte());
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2} {3:X2}   {4}\t {5}," + reg, index, (int)instructionTable[i, 0], opRand, (sbyte)offset, (string)instructionTable[i, 1], offset);
                    break;
                case 0x98:      // [n,R] - 1RR11000, 8 Bit offset, Indirect addressing.
                    offset = GetByteOffset(GetNextByte());
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2} {3:X2}   {4}\t [{5}," + reg + "]", index, (int)instructionTable[i, 0], opRand, (sbyte)offset, (string)instructionTable[i, 1], offset);
                    break;
                case 0x89:      // n,R - 1RR01001, 16 Bit offset, Non indirect addressing.
                    offset = GetWordOffset(GetNextWord());
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2} {3:X4} {4}\t {5}," + reg, index, (int)instructionTable[i, 0], opRand, offset, (string)instructionTable[i, 1], offset);
                    break;
                case 0x99:      // [n,R] - 1RR11001, 16 Bit offset, Indirect addressing.
                    offset = GetWordOffset(GetNextWord());
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2} {3:X4} {4}\t [{5}," + reg + "]", index, (int)instructionTable[i, 0], opRand, offset, (string)instructionTable[i, 1], offset);
                    break;
                case 0x86:      // A,R - 1RR00110, A Register offset, Non indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t A," + reg, index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x96:      // [A,R] - 1RR10110, A Register offset, Indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t [A," + reg + "]", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x85:      // B,R - 1RR00101, B Register offset, Non indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t B," + reg, index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x95:      // [B,R] - 1RR10101, B Register offset, Indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t [B," + reg + "]", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x8B:      // D,R - 1RR01011, D Register offset, Non indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t D," + reg, index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x9B:      // [D,R] - 1RR11011, D Register offset, Indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t [D," + reg + "]", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x80:      // ,R+ - 1RR00000, Auto increment R by 1, Non indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t ," + reg + "+", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x81:      // ,R++ - 1RR00001, Auto increment R by 2, Non indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t ," + reg + "++", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x91:      // [,R++] - 1RR10001, Auto increment R by 2, Indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t [," + reg + "++]", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x82:      // ,-R - 1RR00010, Auto decrement R by 1, Non indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t ,-" + reg, index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x83:      // ,--R - 1RR00011, Auto decrement R by 2, Non indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t ,--" + reg, index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x93:      // [,--R] - 1RR10011, Auto decrement R by 2, Indirect addressing.
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t [,--" + reg + "]", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1]);
                    break;
                case 0x8C:      // n,PCR - 1RR01100, 8 Bit offset, Non indirect addressing.
                    offset = GetByteOffset(GetNextByte());
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2} {3:X2}   {4}\t {5}, PCR", index, (int)instructionTable[i, 0], opRand, (sbyte)offset, (string)instructionTable[i, 1], offset);
                    break;
                case 0x9C:      // [n,PCR] - 1RR01100, 8 Bit offset, Indirect addressing.
                    offset = GetByteOffset(GetNextByte());
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2} {3:X2}   {4}\t [{5}, PCR]", index, (int)instructionTable[i, 0], opRand, (sbyte)offset, (string)instructionTable[i, 1], offset);
                    break;
                case 0x8D:      // n,PCR - 1RR01101, 16 Bit offset, Non indirect addressing.
                    offset = GetWordOffset(GetNextWord());
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2} {3:X2}   {4}\t {5}, PCR", index, (int)instructionTable[i, 0], opRand, (sbyte)offset, (string)instructionTable[i, 1], offset);
                    break;
                case 0x9D:      // [n,PCR] - 1RR01101, 16 Bit offset, Indirect addressing.
                    offset = GetWordOffset(GetNextWord());
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2} {3:X2}   {4}\t [{5}, PCR]", index, (int)instructionTable[i, 0], opRand, (sbyte)offset, (string)instructionTable[i, 1], offset);
                    break;
                case 0x9F:      // [n] - 1RR11111, 16 Bit address, Indirect addressing.
                    offset = GetWordOffset(GetNextWord());
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2} {3:X2}   {4}\t [{5}]", index, (int)instructionTable[i, 0], opRand, (sbyte)offset, (string)instructionTable[i, 1], offset);
                    break;
                default:        // n,R - 0RRnnnnn, 5 Bit offset, Non indirect addressing.
                    offset = (short)(opRand & 0x0F);
                    if ((opRand & 0x10) != 0) // Is sign bit set?
                    {
                        offset = (sbyte)(-offset);
                    }
                    returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t {4}," + reg, index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], offset);
                    break;
            }

            return returnString;
        }
        
        // Formats the output string for instructions that use relative addressing.
        private string FormatDataRelative(int i)
        {
            string returnString = null;
            short opRand;                 
            short offset;


            if (((int)instructionTable[i, 0] >> 8) == 0x10 || (int)instructionTable[i, 0] == 0x16 || (int)instructionTable[i, 0] == 0x17)
            {
                opRand = GetNextWord();
                offset = GetWordOffset(opRand);
                if ((int)instructionTable[i, 0] == 0x16 || (int)instructionTable[i, 0] == 0x17)    // These instructions have 1 byte opcodes and 2 byte offsets. 
                    returnString = String.Format("{0:X4}: {1:X2} {2:X4}    {3}\t {4}, PCR", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], offset);
                else  // Instructions which begin with 0x10 have 2 byte opcodes and 2 byte offsets.
                    returnString = String.Format("{0:X4}: {1:X4} {2:X4}  {3}\t {4}, PCR", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], offset);
            }
            else   // All other instructions have 1 byte opcodes and 1 byte offsets
            {
                opRand = GetNextByte();
                offset = GetByteOffset((byte)opRand);
                returnString = String.Format("{0:X4}: {1:X2} {2:X2}      {3}\t {4}, PCR", index, (int)instructionTable[i, 0], opRand, (string)instructionTable[i, 1], offset);
            }

            return returnString;
        }

        // Use by GetDataIndexed() to get the byte offset value.
        private sbyte GetByteOffset(byte nX)
        {
            sbyte offset;

            if ((nX & 0x80) != 0)   // Is sign bit set?
                offset = (sbyte)(-((nX ^ 0xFF) + 1));  // If so convert from two's complement repersentation and add sign.
            else
                offset = (sbyte)nX;

            return offset;
        }

        // Use by GetDataIndexed() to get the word offset value.
        private short GetWordOffset(short nX)
        {
            short offset;

            if ((nX & 0x8000) != 0)   // Is sign bit set?
                offset = (short)(-((nX ^ 0xFFFF) + 1));  // If so convert from two's complement repersentation and add sign.
            else
                offset = nX;

            return offset;
        }
        
        // Returns a byte of data and increments address by 1.
        private byte GetNextByte()
        {
            return codeToDisassemble[index++];
        }

        // Returns a word of data and increments address by 2.
        private short GetNextWord()
        {
            short word;
            word = (short)GetNextByte();
            word = (short)(word << 8);
            word = (short)(word | (short)GetNextByte());

            return word;
        }
    }
}
